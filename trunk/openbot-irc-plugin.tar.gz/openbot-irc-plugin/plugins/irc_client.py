#!/usr/bin/env python
# -*- coding: utf-8 -*- 
############################################################################
#    Copyright (C) 2005-2007                                               #
#                           Ferraro Luciano (aka lux)                      #
#                            email : luciano.ferraro@gmail.com             #
#                            website : http://ferraro.wordpress.org/       #
#                                                                          #
#                                                                          #
#    This program is free software; you can redistribute it and/or modify  #
#    it under the terms of the GNU General Public License as published by  #
#    the Free Software Foundation; either version 2 of the License, or     #
#    (at your option) any later version.                                   #
#                                                                          #
#    This program is distributed in the hope that it will be useful,       #
#    but WITHOUT ANY WARRANTY; without even the implied warranty of        #
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         #
#    GNU General Public License for more details.                          #
#                                                                          #
#    You should have received a copy of the GNU General Public License     #
#    along with this program; if not, write to the                         #
#    Free Software Foundation, Inc.,                                       #
#    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             #
############################################################################
" The gtk base of OpenBot-IRC "
import sys, os
sys.path.append(os.path.abspath("."))
import gtk_framework, html
class Core:
    "  "
    def __init__(self, core):
        self.core = core
        self.quit_message = "OpenBot-IRC plugin 0.0 - quit"
        self.client_window()
        self.start()
        #for i in ("connectionLost", "signedOn", "userJoined", "kickedFrom",
        #          "userKicked", "modeChanged", "nickChanged", "userRenamed",
        #          "userLeft", "privmsg", "userQuit", "action", "joined"):
        for i in ["joined", "privmsg"]:
            self.core.call(i, getattr(self, "_on_" + i))

    def client_window(self):
        self.root = gtk_framework._window(title="OpenBot-IRC")
        self.root.connect('destroy', self.quit)
        
        send = gtk_framework._button("Send", self.send)
        send.set_flags(gtk.CAN_DEFAULT)
        self.root.set_default(send)
        
        self.send_data = gtk_framework._entry()
        self.send_data.set_activates_default(True)
        
        self.tabs = gtk_framework._notebook()
        self.tabs.connect("switch-page", self._switch_tab)
        
        tables = ( (self.tabs, 0, 10, 0, 1), 
        (self.send_data, 0, 9, 201, 2), 
        (send, 9, 10, 201, 2) )
        self.table = gtk_framework._table(2, 2)
        self.table.attach(self.tabs, 0, 10, 1, 201, xpadding=5)
        self.table.attach(self.send_data, 0, 9, 201, 202, xpadding=5)
        self.table.attach(send, 9, 10, 201, 202, xpadding=5)
        
        self.textviews, self.textview_scrolls = [], []
        self.userlists, self.userlist_scrolls = [], []

    def _channel_to_tab_number(self, chan):
        total_tabs = self.tabs.get_n_pages()
        for num in range(0, total_tabs):
            num_to_chan = self.tabs.get_tab_label_text(self.tabs.get_nth_page(num))
            if num_to_chan == chan:
                return num
    
    def _create_tab(self, chan):
        table = gtk_framework._table()
        
        textview, textview_scroll = gtk_framework._textview(textview=html.HtmlTextView, 
        scroll_window=True, editable=False)
        self.textviews.append(textview)
        self.textview_scrolls.append(textview_scroll)
        
        userslist, userlist_scroll = gtk_framework._textview(scroll_window=True, 
        editable=False, textview=html.HtmlTextView)
        self.userlists.append(userslist)
        self.userlist_scrolls.append(userlist_scroll)

        label = gtk_framework._label(chan)
        
        textview.show()
        textview_scroll.show()
        table.attach(textview_scroll, 0, 9, 0, 1)
        userslist.show()
        userlist_scroll.show()
        table.attach(userlist_scroll, 9, 10, 0, 1)
        table.show()
        
        self.tabs.append_page(table, label)
        self.tabs.set_current_page(self.tabs.get_n_pages()-1)
    
    def _remove_tab(self, tab_number):
        self.tabs.remove_page(tab_number)
    
    def _switch_tab(self, notebook, page, tabnum):
        current_tab = self.tabs.get_tab_label_text(self.tabs.get_nth_page(tabnum))
        self.root.set_title("OpenBot-IRC - " + current_tab)
        
    def _remove_channel(self, channel):
        channel_tab_number = self._channel_to_tab_number(channel)
        if channel_tab_number == None:
            channel_tab_number = self.tabs.get_current_page()
        if not len(channel):
            widget = self.tabs.get_nth_page(channel_tab_number)
            channel = self.tabs.get_tab_label_text(widget)
        self._remove_tab(channel_tab_number)
        del self.textviews[channel_tab_number]
        del self.textview_scrolls[channel_tab_number]
        del self.userlists[channel_tab_number]
        del self.textview_scrollsu[channel_tab_number]
        self.channels_to_part.append(channel)

    def _insert(self, message, channel):
        current_page = self._channel_to_tab_number(channel)
        if current_page == None:
            self._create_tab(channel)
            current_page = self.tabs.get_n_pages()-1
        textview = self.textviews[current_page]
        
        textview.set_editable(True)
        textview.display_html(message)
        textview.set_editable(False)
        self.textview_scrolls[current_page].emit("scroll-child", gtk.SCROLL_END, None)

    def _insert_user(self, channel, user):
        def insert_user(current_page):
            textview = self.user_lists[current_page]
            textview.set_editable(True)
            textview.display_html(user)
            textview.set_editable(False)
        if chan == "-ALL-": # Aggiunge il nick a tutti i chan
            for current_page in range(self.tabs.get_n_pages()):
                insert_user(nick, current_page)
        else: # Aggiunge il nick ad un solo chan
            insert_user(self._channel_to_tab_number(channel))

    def _remove_user(self, channel, user):
        def remove_user(current_page):
            textview = self.userlists[current_page]
            textbuffer = textview.get_buffer()
            textview.set_editable(True)
            
            user_list = textbuffer.get_text(textbuffer.get_start_iter(), 
            textbuffer.get_end_iter())
            new_users_list = ""
            # Qui verra inserita la nuova nicklist senza il nick da cancellare
            for user_ in user_list.split("\n"):
                if (user_ != "") and (user_ != user):
                    # Se il nick non e' quello da eliminare:
                    #  lo aggiunge alla nuova user list
                    new_users_list += "\n" + user_
            
            textbuffer.set_text(new_users_list)
            textview.set_editable(False)
        if chan == "-ALL-": # Elimina il nick a tutti i chan
            for current_page in range(self.tabs.get_n_pages()):
                remove_user(current_page)
        else: # Elimina il nick ad un solo chan
            remove_user(self._channel_to_tab_number(channel))

    def _create_users_list(self, channel, users):
        for user in users.split("\n"):
            self._insert_user(channel, user)

    def part_channels(self, channels):
        channels = channels.replace(" ", "").split(",")
        if channels == "":
            widget = self.tabs.get_nth_page(self.tabs.get_current_page())
            channels = (self.tabs.get_tab_label_text(widget))
        elif type(channels) is str:
            channels = (channels)
        #if not len(self.channels_to_part): # DA RIMUOVERE
        #    self._remove_channel("")       # DA RIMUOVERE
        for channel in channels:
            self.core.irc.leave(channel)

    def join_channels(self, channels):
        channels = channels.replace(" ", "").split(",")
        if type(channels) is str:
            channels = (channels)
        for channel in channels:
            self._create_tab(channel)
            self.core.irc.join(channel)

    def send(self, *args):
        def parser(execution, accept_none=False):
            if len(message) > len(splitted_message):
                a = message[len(splitted_message)+1:]
            elif accept_none:
                a = None
            else:
                return
            eval(execution)
        
        message = self.send_data.get_text()
        self.send_data.set_text("")
        splitted_message = message.split()[0].lower()
        dictionary = {
        "/quit":("self.quit(a)", True), 
        "/join":("self.join_channels(a)"), 
        "/j":("self.join_channels(a)"), 
        "/nick":("self.core.irc.setuser(a)"), 
        "/part":("self.part_channels(a)")
        }
        if dictionary.has_key(splitted_message):
            parser(*dictionary[splitted_message])
        else:
            self.privmsg(message)

    def privmsg(self, message):
        current_page = self.tabs.get_current_page()
        chan = self.tabs.get_tab_label_text(self.tabs.get_nth_page(current_page))
        self.core.privmsg(chan, message)
        
        message = """<div>%s%s</span>: %s</div>""" %(
        red_bold, self.core.conf.botnick, message)
        self._insert(message, chan)

    def quit(self, *args):
        if type(args[0]) is str:
            self.quit_message = args[0]
        self.core.quit(self.quit_message)
        #gtk.main_quit()

    def start(self):
        self.root.add(self.table)
        self.root.show_all()
        self._insert("""
<span size='x-large' weight='heavy' style='font-weight: bold'>
Welcome to OpenBot's IRC plugin</span>""", 
        "OpenBot-IRC")
        #gtk.main()

    def _on_joined(self, channel):
        """Called when I finish joining a channel.
        """
        self._insert("<div>%sSuccerful joined %s!</span></div>" % (
        darkgreen, channel), channel)

    def _on_privmsg(self, user, channel, message):
        """Called when I have a message from a user to me or a channel.
        """
        user = user.split("!")[0]
        if channel == self.core.conf.botnick:
            channel = user
        self._insert("<div>%s%s</span>: %s</div>" % (
        darkgreen_bold, user, message), channel)

def main(core):
    " Start the Plugin "
    Core(core)

red_bold = "<span style='color:red;font-weight: bold'>"
darkgreen = "<span style='color:darkgreen'>"
darkblue_bold = "<span style='color:darkblue;font-weight: bold'>"

#libraries = ("Window", "Table", "Entry", "Button", "Notebook", "Dialog", 
#"Label", "TextBuffer", "TextView", "ScrolledWindow", "VBox", "HBox")
__functions__ = [main]
__revision__ = 0
__call__ = ["gtk"]
#for lib in libraries:
#    __call__.append("gtk." + lib)
