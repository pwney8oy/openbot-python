#!/usr/bin/env python
# -*- coding: utf-8 -*- 
############################################################################
#    Copyright (C) 2005-2007                                               #
#                           Ferraro Luciano (aka lux)                      #
#                            email : luciano.ferraro@gmail.com             #
#                            website : http://ferraro.wordpress.org/       #
#                                                                          #
#                                                                          #
#    This program is free software; you can redistribute it and/or modify  #
#    it under the terms of the GNU General Public License as published by  #
#    the Free Software Foundation; either version 2 of the License, or     #
#    (at your option) any later version.                                   #
#                                                                          #
#    This program is distributed in the hope that it will be useful,       #
#    but WITHOUT ANY WARRANTY; without even the implied warranty of        #
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         #
#    GNU General Public License for more details.                          #
#                                                                          #
#    You should have received a copy of the GNU General Public License     #
#    along with this program; if not, write to the                         #
#    Free Software Foundation, Inc.,                                       #
#    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             #
############################################################################
import gtk

def _window(title=""):
    window = gtk.Window()
    window.set_title(title)
    return window

def _entry():
    return gtk.Entry()

def _button(text, receiver):
    button = gtk.Button(text)
    button.connect("clicked", receiver, "")
    return button

def _label(text):
    return gtk.Label(text)

def _notebook():
    return gtk.Notebook()

def _table(rows=1, columns=1, homogeneous=False, tables=None):
    """
    tables : tuple with books
            e.g. _table(((self.toolbar, 0, 10, 0, 1, xpadding=5), (self.tabs, 0, 10, 1, 201, xpadding=5))
    """
    table = gtk.Table(rows, columns, homogeneous)
    if tables != None:
        for tab in tables:
            table.attach(*tab)
    return table

def _textbuffer():
    return gtk.TextBuffer()

def _textview(textbuffer=None, scroll_window=False, scroll_policy=(gtk.POLICY_AUTOMATIC, gtk.POLICY_AUTOMATIC), editable=True, textview=gtk.TextView):
    if textbuffer != None:
        textview = textview(textbuffer)
    else:
        textview = textview()
    textview.set_editable(editable)
    if scroll_window:
        scroll_window = gtk.ScrolledWindow()
        scroll_window.add(textview)
        scroll_window.set_policy(*scroll_policy)
        return textview, scroll_window
    return textview

