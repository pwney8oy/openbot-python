import handler
handler = handler.Core()
def stampa_qualche_cazzata(cazzata):
    print cazzata
handler.add("print", stampa_qualche_cazzata)
handler.call("print", "BUAHAHHA CHE CAZZATA oo")
handler.remove("print") # ora non puoi + chiamare `print`
handler.call("print", "ora non va ^^")
